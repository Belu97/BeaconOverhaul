package dev.sapphic.beacons.client.mixin;

import net.minecraft.class_1294;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4603;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4603.class)
abstract class ScreenEffectRendererMixin {
  @Inject(
      method = "renderFire(Lnet/minecraft/client/Minecraft;Lcom/mojang/blaze3d/vertex/PoseStack;)V",
      at = @At("HEAD"), require = 1, allow = 1, cancellable = true)
  private static void omitFireOverlayIfResistant(final class_310 mc, final class_4587 stack, final CallbackInfo ci) {
    if ((mc.field_1724 != null) && mc.field_1724.method_6059(class_1294.field_5918)) {
      ci.cancel();
    }
  }
}
