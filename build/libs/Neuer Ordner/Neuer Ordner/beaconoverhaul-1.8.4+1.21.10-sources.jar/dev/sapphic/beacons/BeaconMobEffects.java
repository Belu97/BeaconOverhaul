package dev.sapphic.beacons;

import dev.sapphic.beacons.mixin.BeaconBlockEntityAccessor;
import dev.sapphic.beacons.mixin.GameRulesAccessor;
import dev.sapphic.beacons.mixin.IntegerValueAccessor;
import net.fabricmc.api.ModInitializer;
import net.minecraft.class_1291;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1657;
import net.minecraft.class_1928;
import net.minecraft.class_2378;
import net.minecraft.class_2580;
import net.minecraft.class_2960;
import net.minecraft.class_4081;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public final class BeaconMobEffects implements ModInitializer {
  static final String NAMESPACE = "beaconoverhaul";

  public static final class_1928.class_4313<class_1928.class_4312> LONG_REACH_INCREMENT =
      GameRulesAccessor.callRegister(
          "longReachIncrement", class_1928.class_5198.field_24094, IntegerValueAccessor.callCreate(2));

  public static final class_6880<class_1291> LONG_REACH =
      class_2378.method_47985(class_7923.field_41174, class_2960.method_60655(NAMESPACE, "long_reach"),
          new class_1291(class_4081.field_18271, 0xDEF58F) {
          }.method_5566(class_5134.field_47758,
              class_2960.method_60655(NAMESPACE, "long_reach_block"), 1.0, class_1322.class_1323.field_6328
          ).method_5566(class_5134.field_47759,
              class_2960.method_60655(NAMESPACE, "long_reach_entity"), 1.0, class_1322.class_1323.field_6328
          ));

  public static final class_6880<class_1291> NUTRITION =
      class_2378.method_47985(class_7923.field_41174, class_2960.method_60655(NAMESPACE, "nutrition"),
          new class_1291(class_4081.field_18271, 0x8A1A22) {
            @Override
            public boolean method_5572(net.minecraft.class_3218 level, class_1309 entity, int amplifier) {
              if (entity instanceof class_1657 player) {
                if (player.method_7344().method_7587()) {
                  player.method_7344().method_7585(1, 0.0F);
                }
              }
              return true;
            }

            @Override
            public boolean method_5552(int duration, int amplifier) {
              return (duration % Math.max(1, (100 >> amplifier))) == 0;
            }
          });

  private static void addMobEffectsToBeacon() {
    final List<List<class_6880<class_1291>>> effects = new ArrayList<>();
    for (List<class_6880<class_1291>> tier : class_2580.field_11801) {
      effects.add(new ArrayList<>(tier));
    }

    effects.get(0).add(class_1294.field_5925);
    effects.get(1).add(LONG_REACH);
    effects.get(2).add(NUTRITION);
    effects.get(3).add(class_1294.field_5918);
    effects.get(3).add(class_1294.field_5906);

    // Update BEACON_EFFECTS
    List<List<class_6880<class_1291>>> immutableEffects = effects.stream()
        .map(List::copyOf)
        .collect(Collectors.toList());
    BeaconBlockEntityAccessor.setBeaconEffects(List.copyOf(immutableEffects));

    // Update VALID_EFFECTS
    BeaconBlockEntityAccessor.setValidEffects(
        effects.stream().flatMap(Collection::stream).collect(Collectors.toSet())
    );
  }

  @Override
  public void onInitialize() {
    addMobEffectsToBeacon();
  }
}
