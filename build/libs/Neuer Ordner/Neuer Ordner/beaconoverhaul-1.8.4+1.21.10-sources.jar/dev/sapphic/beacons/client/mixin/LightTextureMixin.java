package dev.sapphic.beacons.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_765;
import org.checkerframework.checker.nullness.qual.MonotonicNonNull;
import org.checkerframework.checker.nullness.qual.Nullable;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Environment(EnvType.CLIENT)
@Mixin(class_765.class)
abstract class LightTextureMixin /*implements AutoCloseable*/ {
  @Shadow
  @Final
  private @MonotonicNonNull class_310 minecraft;

  @ModifyVariable(
      method = "updateLightTexture(F)V",
      at = @At(
          target = "Lorg/joml/Vector3f;<init>(Lorg/joml/Vector3fc;)V",
          shift = Shift.BEFORE, value = "INVOKE", opcode = Opcodes.INVOKESPECIAL, ordinal = 0, remap = false),
      index = 15, require = 1, allow = 1)
  private float fullBrightNightVision(final float skyLight) {
    final @Nullable class_746 player = this.minecraft.field_1724;

    if (player == null) {
      return skyLight;
    }

    final @Nullable class_1293 nightVision = player.method_6112(class_1294.field_5925);
    return ((nightVision != null) && (nightVision.method_5578() > 0)) ? 15.0F : skyLight;
  }
}
