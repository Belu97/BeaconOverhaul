package dev.sapphic.beacons.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_4013;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Environment(EnvType.CLIENT)
@Mixin(class_757.class)
abstract class GameRendererMixin implements class_4013 /*, AutoCloseable*/ {
  @Inject(
      method = "getNightVisionScale(Lnet/minecraft/world/entity/LivingEntity;F)F",
      at = @At(shift = Shift.BY, by = -2, value = "CONSTANT", args = "intValue=200"),
      locals = LocalCapture.CAPTURE_FAILHARD, cancellable = true, require = 1, allow = 1)
  private static void noNightVisionFlickerWhenAmbient(
      final class_1309 entity, final float partialTick, final CallbackInfoReturnable<Float> cir,
      final class_1293 effect) {
    if (effect.method_5591()) {
      cir.setReturnValue(1.0F);
    }
  }
}
