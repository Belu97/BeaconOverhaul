package dev.sapphic.beacons.client;

import dev.sapphic.beacons.TieredBeacon;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1291;
import net.minecraft.class_1294;
import net.minecraft.class_2561;
import net.minecraft.class_466;
import net.minecraft.class_5250;

@Environment(EnvType.CLIENT)
public final class BeaconPowerTooltips {
  private static final String[] EFFECT_SUFFIXES = { " II", " III", " IV" };

  private BeaconPowerTooltips() {
  }

  public static class_5250 createTooltip(
      final class_466 screen, final net.minecraft.class_6880<class_1291> effect, final boolean upgrade) {
    final var component = class_2561.method_43471(effect.comp_349().method_5567());

    if (!effect.method_55838(class_1294.field_5906) && !effect.method_55838(class_1294.field_5918)) {
      var potency = upgrade ? 1 : 0;

      if (!effect.method_55838(class_1294.field_5925)) {
        potency += ((TieredBeacon) screen.method_17577()).getTier().ordinal();
      }

      if (potency > 0) {
        return component.method_27693(EFFECT_SUFFIXES[potency - 1]);
      }
    }

    return component;
  }
}
