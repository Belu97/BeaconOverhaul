package dev.sapphic.beacons.mixin;

import net.minecraft.class_1928;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1928.class)
public interface GameRulesAccessor {
  @Invoker
  static <T extends class_1928.class_4315<T>> class_1928.class_4313<T> callRegister(
      final String name, final class_1928.class_5198 category, final class_1928.class_4314<T> type) {
    throw new AssertionError();
  }
}
