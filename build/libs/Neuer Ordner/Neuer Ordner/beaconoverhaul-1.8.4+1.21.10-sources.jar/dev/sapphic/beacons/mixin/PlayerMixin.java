package dev.sapphic.beacons.mixin;

import dev.sapphic.beacons.BeaconMobEffects;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1657.class)
abstract class PlayerMixin extends class_1309 {
  PlayerMixin(final class_1299<? extends class_1309> type, final class_1937 level) {
    super(type, level);
  }

  @ModifyVariable(method = "canEat(Z)Z", require = 1, allow = 1, argsOnly = true, at = @At("HEAD"))
  private boolean orHasNutritionEffect(final boolean alwaysEdibleFood) {
    return alwaysEdibleFood || this.method_6059(BeaconMobEffects.NUTRITION);
  }
}
