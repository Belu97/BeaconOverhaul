package dev.sapphic.beacons.client.mixin;

import dev.sapphic.beacons.BeaconMobEffects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_329;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Environment(EnvType.CLIENT)
@Mixin(class_329.class)
abstract class GuiMixin {
  @Shadow
  private net.minecraft.class_310 minecraft;

  @Shadow
  private class_1657 getCameraPlayer() {
    throw new AssertionError();
  }

  @ModifyVariable(
      method = "renderPlayerHealth(Lnet/minecraft/client/gui/GuiGraphics;)V",
      at = @At(
          target = "Lnet/minecraft/util/RandomSource;nextInt(I)I",
          ordinal = 0, shift = Shift.BY, by = 5,value = "INVOKE", opcode = Opcodes.INVOKEINTERFACE),
      index = 24, require = 1, allow = 1)
  private int noNutritionHungerShake(final int randY) {
    final var player = this.getCameraPlayer();

    if ((player != null) && !player.method_7344().method_7587()) {
      if (player.method_6059(BeaconMobEffects.NUTRITION)) {
        return this.minecraft.method_22683().method_4502() - 39;
      }
    }

    return randY;
  }
}
