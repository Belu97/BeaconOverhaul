package dev.sapphic.beacons.mixin;

import dev.sapphic.beacons.PotencyTier;
import dev.sapphic.beacons.TieredBeacon;
import net.minecraft.class_1703;
import net.minecraft.class_1704;
import net.minecraft.class_3913;
import net.minecraft.class_3917;
import org.checkerframework.checker.nullness.qual.MonotonicNonNull;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(class_1704.class)
abstract class BeaconMenuMixin extends class_1703 implements TieredBeacon {
  @Shadow
  @Final
  private @MonotonicNonNull class_3913 beaconData;

  BeaconMenuMixin(final @Nullable class_3917<?> type, final int id) {
    super(type, id);
  }

  @Override
  @Unique
  public final PotencyTier getTier() {
    return PotencyTier.values()[this.beaconData.method_17390(3)];
  }

  @ModifyConstant(
      method = "<init>(ILnet/minecraft/world/Container;)V",
      require = 1, allow = 1, constant = @Constant(intValue = 3))
  private static int getNewDataCount(final int dataCount) {
    return 3 + 1;
  }

  @ModifyConstant(
      method =
          "<init>(ILnet/minecraft/world/Container;Lnet/minecraft/world/inventory/ContainerData;"
              + "Lnet/minecraft/world/inventory/ContainerLevelAccess;)V",
      constant = @Constant(intValue = 3, ordinal = 0), require = 1, allow = 1)
  private int getDataPreconditionCount(final int dataCount) {
    return 3 + 1;
  }
}
