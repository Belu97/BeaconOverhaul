package dev.sapphic.beacons.client.mixin;

import dev.sapphic.beacons.client.BeaconPowerTooltips;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1291;
import net.minecraft.class_466;
import net.minecraft.class_7919;
import org.checkerframework.checker.nullness.qual.MonotonicNonNull;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_466.class_469.class)
abstract class PowerButtonMixin extends class_466.class_470 {
  @Unique
  @SuppressWarnings("ConstantConditions")
  private final boolean upgrade = (Object) this instanceof class_466.class_6393;

  @Shadow(aliases = "this$0")
  @Final
  private @MonotonicNonNull class_466 this$0;

  @Shadow
  private net.minecraft.class_6880<class_1291> effect;

  PowerButtonMixin(final int x, final int y) {
    super(x, y);
  }

  private void setTieredTooltip(final net.minecraft.class_6880<class_1291> effect) {
    this.method_47400(class_7919.method_47408(BeaconPowerTooltips.createTooltip(this.this$0, effect, this.upgrade), null));
  }

  @Inject(method = "setEffect(Lnet/minecraft/core/Holder;)V", at = @At("RETURN"), require = 1, allow = 1)
  private void setTieredTooltip(final net.minecraft.class_6880<class_1291> effect, final CallbackInfo ci) {
    this.setTieredTooltip(this.effect);
  }

  @Inject(method = "updateStatus(I)V", at = @At("TAIL"), require = 1, allow = 1)
  private void updateTieredTooltip(final CallbackInfo ci) {
    if (!this.upgrade) {
      this.setTieredTooltip(this.effect);
    }
  }
}
