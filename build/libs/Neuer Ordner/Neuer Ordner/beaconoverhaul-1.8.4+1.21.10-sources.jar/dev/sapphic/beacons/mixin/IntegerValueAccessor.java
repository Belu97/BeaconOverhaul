package dev.sapphic.beacons.mixin;

import net.minecraft.class_1928;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1928.class_4312.class)
public interface IntegerValueAccessor {
  @Invoker
  static class_1928.class_4314<class_1928.class_4312> callCreate(final int defaultValue) {
    throw new AssertionError();
  }
}
