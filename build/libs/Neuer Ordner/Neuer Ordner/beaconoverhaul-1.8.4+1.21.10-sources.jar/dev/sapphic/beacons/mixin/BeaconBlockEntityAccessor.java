package dev.sapphic.beacons.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Set;
import net.minecraft.class_1291;
import net.minecraft.class_2580;

@Mixin(class_2580.class)
public interface BeaconBlockEntityAccessor {
  @Accessor("VALID_EFFECTS")
  @Mutable
  static void setValidEffects(final Set<net.minecraft.class_6880<class_1291>> value) {
    throw new AssertionError();
  }

  @Accessor("BEACON_EFFECTS")
  @Mutable
  static void setBeaconEffects(final java.util.List<java.util.List<net.minecraft.class_6880<class_1291>>> value) {
    throw new AssertionError();
  }
}
