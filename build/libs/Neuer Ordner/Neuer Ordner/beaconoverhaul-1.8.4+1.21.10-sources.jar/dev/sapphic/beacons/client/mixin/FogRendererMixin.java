package dev.sapphic.beacons.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_758;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin(class_758.class)
abstract class FogRendererMixin {
  // In 1.21.10, setupColor is replaced by computeFogColor which returns a Vector4f
  // and static color fields are gone. We'll need a more complex injection to port this correctly.
  // For now, we'll keep the method signature updated but disable the logic.

  @Inject(
      method = "computeFogColor(Lnet/minecraft/client/Camera;FLnet/minecraft/client/multiplayer/ClientLevel;IFZ)Lorg/joml/Vector4f;",
      at = @At(
          target = "Lnet/minecraft/client/renderer/GameRenderer;"
              + "getNightVisionScale(Lnet/minecraft/world/entity/LivingEntity;F)F",
          value = "INVOKE"),
      cancellable = true, require = 0) // require = 0 until we verify the target in mapped environment
  private void skipNightVisionColorShift(
      final class_4184 camera, final float f, final class_638 level, final int i, final float g, final boolean bl,
      final CallbackInfoReturnable<org.joml.Vector4f> cir
  ) {
    final class_1309 living = (class_1309) camera.method_19331();
    final class_1293 nightVision = living.method_6112(class_1294.field_5925);

    if ((nightVision != null) && (nightVision.method_5578() > 0)) {
      // Logic to return unshifted color would go here
    }
  }
}
