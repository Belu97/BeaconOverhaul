package dev.sapphic.beacons;

import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public enum PotencyTier {
  NONE,
  LOW,
  HIGH;

  public static final class_6862<class_2248> LOW_POTENCY_BLOCKS = createBlockTag("low_potency");
  public static final class_6862<class_2248> HIGH_POTENCY_BLOCKS = createBlockTag("high_potency");

  private static class_6862<class_2248> createBlockTag(final String name) {
    return class_6862.method_40092(class_7924.field_41254, class_2960.method_60655(BeaconMobEffects.NAMESPACE, name));
  }
}
