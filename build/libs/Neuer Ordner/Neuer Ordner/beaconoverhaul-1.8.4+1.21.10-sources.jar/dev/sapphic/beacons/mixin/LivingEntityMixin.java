package dev.sapphic.beacons.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1291;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1324;
import net.minecraft.class_1937;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import org.checkerframework.checker.nullness.qual.MonotonicNonNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
abstract class LivingEntityMixin extends class_1297 {
  @Unique
  private @MonotonicNonNull Double baseUpStep;

  @Unique
  private boolean stepIncreased;

  LivingEntityMixin(final class_1299<?> type, final class_1937 level) {
    super(type, level);
  }

  @Shadow
  public abstract boolean hasEffect(final class_6880<class_1291> effect);

  @Shadow
  public abstract class_1324 getAttribute(final class_6880<net.minecraft.class_1320> attribute);


  @Inject(method = "baseTick()V", at = @At("HEAD"), require = 1)
  private void setBaseUpStep(final CallbackInfo ci) {
    if (this.baseUpStep == null) {
      class_1324 stepAttr = this.getAttribute(class_5134.field_47761);
      if (stepAttr != null) {
        this.baseUpStep = stepAttr.method_6201();
      }
    }
  }

  @Inject(method = "tickEffects()V", at = @At("HEAD"), require = 1)
  private void updateJumpBoostStepAssist(final CallbackInfo ci) {
    if (this.hasEffect(class_1294.field_5913) && !this.method_18276()) {
      if (!this.stepIncreased) {
        class_1324 stepAttr = this.getAttribute(class_5134.field_47761);
        if (stepAttr != null) stepAttr.method_6192(1.0);
        this.stepIncreased = true;
      }
    } else if (this.stepIncreased) {
      class_1324 stepAttr = this.getAttribute(class_5134.field_47761);
      if (stepAttr != null && this.baseUpStep != null) stepAttr.method_6192(this.baseUpStep);
      this.stepIncreased = false;
    }
  }

  @ModifyExpressionValue(
      method = "getEffectiveGravity()D",
      at = @At(value = "CONSTANT", args = "doubleValue=0.01"),
      require = 1)
  private double dropIfCrouching(final double slowFallingGravity) {
    return this.method_18276() ? this.method_56989() : slowFallingGravity;
  }

  @Inject(
      method = "travel(Lnet/minecraft/world/phys/Vec3;)V",
      at = @At(
          target = "Lnet/minecraft/world/entity/LivingEntity;travelInAir(Lnet/minecraft/world/phys/Vec3;)V",
          value = "INVOKE"),
      require = 1)
  private void dropIfCrouching(final net.minecraft.class_243 vec3, final CallbackInfo ci) {
    if (this.method_18276()) {
      // In 1.21.10, we don't need to manually modify deltaMovement here if we use getEffectiveGravity
      // But the original mod might have done more.
    }
  }
}
