package dev.sapphic.beacons.client.mixin;

import dev.sapphic.beacons.client.BeaconPowerTooltips;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1291;
import net.minecraft.class_466;
import net.minecraft.class_7919;
import org.checkerframework.checker.nullness.qual.MonotonicNonNull;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_466.class_469.class)
abstract class PowerButtonMixin extends class_466.class_470 {
  @Unique
  @SuppressWarnings("ConstantConditions")
  private final boolean upgrade = (Object) this instanceof class_466.class_6393;

  @Unique
  private class_466 screen;

  @Inject(method = "<init>(IILnet/minecraft/core/Holder;ZI)V", at = @At("RETURN"))
  private void captureScreen(int x, int y, net.minecraft.class_6880<class_1291> effect, boolean upgrade, int tier, CallbackInfo ci) {
    // Since this is a non-static inner class, we should ideally have access to the outer instance.
    // However, Mixin is failing to find this$0. 
    // We can use an Accessor or just cast 'this' if we know the structure.
    // Actually, in the constructor of BeaconPowerButton, the first argument is BeaconScreen (from the bytecode).
    // But Mixin's constructor signature usually hides the outer instance argument.
  }

  @Shadow
  private net.minecraft.class_6880<class_1291> effect;

  PowerButtonMixin(final int x, final int y) {
    super(x, y);
  }

  private void setTieredTooltip(final net.minecraft.class_6880<class_1291> effect) {
    // If we can't get the screen instance, we might need a different approach.
    // Let's try to get it from the Minecraft instance (currentScreen).
    final var minecraft = net.minecraft.class_310.method_1551();
    if (minecraft.field_1755 instanceof final class_466 beaconScreen) {
      this.method_47400(class_7919.method_47408(BeaconPowerTooltips.createTooltip(beaconScreen, effect, this.upgrade), null));
    }
  }

  @Inject(method = "setEffect(Lnet/minecraft/core/Holder;)V", at = @At("RETURN"), require = 1, allow = 1)
  private void setTieredTooltip(final net.minecraft.class_6880<class_1291> effect, final CallbackInfo ci) {
    this.setTieredTooltip(this.effect);
  }

  @Inject(method = "updateStatus(I)V", at = @At("TAIL"), require = 1, allow = 1)
  private void updateTieredTooltip(final CallbackInfo ci) {
    if (!this.upgrade) {
      this.setTieredTooltip(this.effect);
    }
  }
}
