package dev.sapphic.beacons;

import net.minecraft.class_2580;
import net.minecraft.class_3913;

public final class TieredBeaconData implements class_3913 {
  private final class_2580 beacon;
  private final class_3913 delegate;

  public TieredBeaconData(final class_2580 beacon, final class_3913 delegate) {
    this.beacon = beacon;
    this.delegate = delegate;
  }

  @Override
  public int method_17390(final int index) {
    if (index == 3) {
      return ((TieredBeacon) this.beacon).getTier().ordinal();
    }
    return this.delegate.method_17390(index);
  }

  @Override
  public void method_17391(final int index, final int value) {
    if (index == 3) {
      ((MutableTieredBeacon) this.beacon).setTier(PotencyTier.values()[value]);
      return;
    }
    this.delegate.method_17391(index, value);
  }

  @Override
  public int method_17389() {
    return 4;
  }
}
