package dev.sapphic.beacons.client.mixin;

import dev.sapphic.beacons.BeaconMobEffects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Environment(EnvType.CLIENT)
@Mixin(class_329.class)
abstract class GuiMixin {
  @Shadow
  @Final
  private class_310 minecraft;

  @Shadow
  private class_1657 getCameraPlayer() {
    throw new AssertionError();
  }

  @ModifyVariable(
      method = "renderFood(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/world/entity/player/Player;II)V",
      at = @At(value = "STORE", ordinal = 1), // Targeting the second store to slot 8 (after the shake logic)
      index = 8, require = 1)
  private int noNutritionHungerShake(final int shakenY, final class_332 graphics, final class_1657 player, final int x, final int y) {
    final class_1657 cameraPlayer = this.getCameraPlayer();

    if ((cameraPlayer != null) && !cameraPlayer.method_7344().method_7587()) {
      if (cameraPlayer.method_6059(BeaconMobEffects.NUTRITION)) {
        return y; // Return the original Y coordinate (parameter 'y') instead of the shaken one
      }
    }

    return shakenY;
  }
}
