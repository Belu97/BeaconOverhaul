package dev.sapphic.beacons.client.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_765;
import org.checkerframework.checker.nullness.qual.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Environment(EnvType.CLIENT)
@Mixin(class_765.class)
abstract class LightTextureMixin {
  @Shadow
  @Final
  private class_310 minecraft;

  @ModifyExpressionValue(
      method = "updateLightTexture(F)V",
      at = @At(value = "INVOKE", target = "Ljava/lang/Double;floatValue()F", ordinal = 1),
      require = 1)
  private float fullBrightNightVision(final float gamma) {
    final @Nullable class_746 player = this.minecraft.field_1724;

    if (player == null) {
      return gamma;
    }

    final @Nullable class_1293 nightVision = player.method_6112(class_1294.field_5925);
    return ((nightVision != null) && (nightVision.method_5578() > 0)) ? 15.0F : gamma;
  }
}
