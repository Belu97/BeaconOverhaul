package dev.sapphic.beacons.client.mixin;

import net.minecraft.class_1058;
import net.minecraft.class_1294;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4603;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4603.class)
abstract class ScreenEffectRendererMixin {
  @Inject(
      method = "renderFire(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;Lnet/minecraft/client/renderer/texture/TextureAtlasSprite;)V",
      at = @At("HEAD"), require = 1, allow = 1, cancellable = true)
  private static void omitFireOverlayIfResistant(final class_4587 stack, final class_4597 bufferSource, final class_1058 sprite, final CallbackInfo ci) {
    final class_310 mc = class_310.method_1551();
    if ((mc.field_1724 != null) && mc.field_1724.method_6059(class_1294.field_5918)) {
      ci.cancel();
    }
  }
}
