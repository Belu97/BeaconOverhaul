package dev.sapphic.beacons.mixin;

import dev.sapphic.beacons.MutableTieredBeacon;
import dev.sapphic.beacons.PotencyTier;
import dev.sapphic.beacons.TieredBeacon;
import org.checkerframework.checker.nullness.qual.MonotonicNonNull;
import org.jetbrains.annotations.Nullable;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.Objects;
import net.minecraft.class_1291;
import net.minecraft.class_1294;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2580;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.class_3908;
import net.minecraft.class_3913;

@Mixin(class_2580.class)
abstract class BeaconBlockEntityMixin extends class_2586 implements class_3908, MutableTieredBeacon {
  @Shadow
  int levels;

  @Unique
  private PotencyTier tier = PotencyTier.NONE;

  BeaconBlockEntityMixin(final class_2591<?> type, final class_2338 pos, final class_2680 state) {
    super(type, pos, state);
  }

  @Unique
  @Override
  public final PotencyTier getTier() {
    return this.tier;
  }

  @Unique
  @Override
  public final void setTier(final PotencyTier tier) {
    this.tier = Objects.requireNonNull(tier);
  }

  @Inject(
      method =
          "tick(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;"
              + "Lnet/minecraft/world/level/block/state/BlockState;"
              + "Lnet/minecraft/world/level/block/entity/BeaconBlockEntity;)V",
      at = @At(
          target = "Lnet/minecraft/world/level/block/entity/BeaconBlockEntity;"
              + "updateBase(Lnet/minecraft/world/level/Level;III)I",
          shift = At.Shift.BY, by = 2, value = "INVOKE", opcode = Opcodes.INVOKESTATIC),
      locals = LocalCapture.CAPTURE_FAILHARD, require = 1, allow = 1)
  private static void updateTier(
      final class_1937 level, final class_2338 pos, final class_2680 state, final class_2580 beacon,
      final CallbackInfo ci, final int x, final int y, final int z) {
    var tier = PotencyTier.HIGH;
    var layerOffset = 1;

    layerCheck:
    while (layerOffset <= 4) {
      final var yOffset = y - layerOffset;

      if (yOffset < level.method_31607()) {
        tier = PotencyTier.NONE;
        break;
      }

      for (var xOffset = x - layerOffset; xOffset <= (x + layerOffset); ++xOffset) {
        for (var zOffset = z - layerOffset; zOffset <= (z + layerOffset); ++zOffset) {
          final var stateAt = level.method_8320(new class_2338(xOffset, yOffset, zOffset));

          if (!stateAt.method_26164(class_3481.field_22275)) {
            if (layerOffset == 1) {
              tier = PotencyTier.NONE;
            }

            break layerCheck;
          }

          final PotencyTier tierAt;

          if (stateAt.method_26164(PotencyTier.HIGH_POTENCY_BLOCKS)) {
            tierAt = PotencyTier.HIGH;
          } else if (stateAt.method_26164(PotencyTier.LOW_POTENCY_BLOCKS)) {
            tierAt = PotencyTier.LOW;
          } else {
            tierAt = PotencyTier.NONE;
          }

          if (tierAt.ordinal() < tier.ordinal()) {
            tier = tierAt;
          }
        }
      }

      ++layerOffset;
    }

    ((MutableTieredBeacon) beacon).setTier(tier);
  }

  @ModifyVariable(
      method =
          "applyEffects(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I"
              + "Lnet/minecraft/core/Holder;Lnet/minecraft/core/Holder;)V",
      at = @At(value = "STORE", opcode = Opcodes.DSTORE, ordinal = 0),
      index = 5, require = 1, allow = 1)
  private static double modifyEffectRadius(final double radius, final class_1937 level, final class_2338 pos) {
    if (level.method_8321(pos) instanceof final TieredBeacon beacon) {
      return radius + (10.0 * beacon.getTier().ordinal());
    }

    return radius; // (levels * 10) + 10
  }

  @ModifyVariable(
      method =
          "applyEffects(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I"
              + "Lnet/minecraft/core/Holder;Lnet/minecraft/core/Holder;)V",
      at = @At(value = "STORE", opcode = Opcodes.ISTORE, ordinal = 0),
      index = 7, require = 1, allow = 1)
  private static int modifyPrimaryAmplifier(
      final int primaryAmplifier, final class_1937 level, final class_2338 pos, final int levels,
      final @Nullable net.minecraft.class_6880<class_1291> primaryEffect) {
    if (primaryEffect != class_1294.field_5925) {
      if (level.method_8321(pos) instanceof final TieredBeacon beacon) {
        return beacon.getTier().ordinal();
      }
    }

    return primaryAmplifier; // 0
  }

  @ModifyVariable(
      method =
          "applyEffects(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I"
              + "Lnet/minecraft/core/Holder;Lnet/minecraft/core/Holder;)V",
      at = @At(value = "STORE", opcode = Opcodes.ISTORE, ordinal = 1),
      index = 7, require = 1, allow = 1)
  private static int modifyPotentPrimaryAmplifier(
      final int primaryAmplifier, final class_1937 level, final class_2338 pos, final int levels,
      final @Nullable net.minecraft.class_6880<class_1291> primaryEffect, final @Nullable net.minecraft.class_6880<class_1291> secondaryEffect) {
    if ((primaryEffect != class_1294.field_5925)
        && (secondaryEffect != class_1294.field_5906)
        && (secondaryEffect != class_1294.field_5918)) {
      if (level.method_8321(pos) instanceof final TieredBeacon beacon) {
        return primaryAmplifier + beacon.getTier().ordinal();
      }
    }

    return primaryAmplifier; // 1
  }

  @ModifyVariable(
      method =
          "applyEffects(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I"
              + "Lnet/minecraft/core/Holder;Lnet/minecraft/core/Holder;)V",
      at = @At(value = "STORE", opcode = Opcodes.ISTORE, ordinal = 0),
      index = 8, require = 1, allow = 1)
  private static int modifyDuration(final int duration, final class_1937 level, final class_2338 pos, final int levels) {
    if (level.method_8321(pos) instanceof final TieredBeacon beacon) {
      return ((9 * (beacon.getTier().ordinal() + 1)) + (levels * 2)) * 20;
    }

    return duration; // (9 + levels * 2) * 20
  }

  // Cannot use ModifyArg here as we need to capture the target method parameters
  @ModifyConstant(
      method =
          "applyEffects(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I"
              + "Lnet/minecraft/core/Holder;Lnet/minecraft/core/Holder;)V",
      constant = @Constant(/*intValue = 0,*/ ordinal = 1),
      require = 1, allow = 1)
  private static int modifySecondaryAmplifier(
      final int secondaryAmplifier, final class_1937 level, final class_2338 pos, final int levels,
      final @Nullable net.minecraft.class_6880<class_1291> primaryEffect, final @Nullable net.minecraft.class_6880<class_1291> secondaryEffect) {
    if ((secondaryEffect != class_1294.field_5906)
        && (secondaryEffect != class_1294.field_5918)) {
      if (level.method_8321(pos) instanceof final TieredBeacon beacon) {
        return beacon.getTier().ordinal();
      }
    }

    return secondaryAmplifier; // 0
  }

  @ModifyArg(
      method = "createMenu(ILnet/minecraft/world/entity/player/Inventory;Lnet/minecraft/world/entity/player/Player;)Lnet/minecraft/world/inventory/AbstractContainerMenu;",
      at = @At(
          value = "INVOKE",
          target = "Lnet/minecraft/world/inventory/BeaconMenu;<init>(ILnet/minecraft/world/Container;Lnet/minecraft/world/inventory/ContainerData;Lnet/minecraft/world/inventory/ContainerLevelAccess;)V"
      ),
      index = 2, require = 1, allow = 1
  )
  private class_3913 wrapTieredData(final class_3913 data) {
    return new dev.sapphic.beacons.TieredBeaconData((class_2580) (Object) this, data);
  }
}
